# Function to obtain orthologous proteins
## input:
### protein (string) --> Protein label or ID. Example: "BRCA1", "P38398".
## output: orthologous proteins and their taxa.

prot2ortho <- function(protein) {
  library(SPARQL)
  
  # Endpoint SPARQL
  endpoint_sparql <- "https://2407.biogateway.eu/sparql"
  
  # Define the prefixes and common parts of the query
  prefixes <- 
    "
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    PREFIX sch: <http://schema.org/>
    PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX obo: <http://purl.obolibrary.org/obo/>
    PREFIX sio: <http://semanticscience.org/resource/>
    PREFIX oboowl: <http://www.geneontology.org/formats/oboInOwl#>
    "
  
  query <- sprintf(
    "
    %s
    SELECT DISTINCT ?prot_label ?orthology_relation_label ?taxon
    WHERE {
      GRAPH <http://rdf.biogateway.eu/graph/prot> {
        ?prot skos:prefLabel \"%s\" .
      }
      GRAPH <http://rdf.biogateway.eu/graph/ortho> {
        ?uri rdf:object ?prot ;
             rdf:subject ?ortho_prot ;
             skos:prefLabel ?orthology_relation_label .
      }
      GRAPH <http://rdf.biogateway.eu/graph/prot> {
        ?ortho_prot skos:prefLabel ?prot_label ;
               obo:RO_0002162 ?ncbi_taxon .
      }
      GRAPH <http://rdf.biogateway.eu/graph/taxon> {
        ?ncbi_taxon rdfs:label ?taxon .
      }
    }
    ", prefixes, protein
  )
  
  # Run query
  results <- SPARQL(endpoint_sparql, query)$results
  
  if (nrow(results) == 0) {
    # Alternative query with altLabel
    query_alt_label <- sprintf(
      "
      %s
      SELECT DISTINCT ?prot_label ?orthology_relation_label ?taxon
      WHERE {
        GRAPH <http://rdf.biogateway.eu/graph/prot> {
          ?prot skos:altLabel \"%s\" .
        }
        GRAPH <http://rdf.biogateway.eu/graph/ortho> {
          ?uri rdf:object ?prot ;
               rdf:subject ?ortho_prot ;
               skos:prefLabel ?orthology_relation_label .
        }
        GRAPH <http://rdf.biogateway.eu/graph/prot> {
          ?ortho_prot skos:prefLabel ?prot_label ;
                 obo:RO_0002162 ?ncbi_taxon .
        }
        GRAPH <http://rdf.biogateway.eu/graph/taxon> {
          ?ncbi_taxon rdfs:label ?taxon .
        }
      }
      ", prefixes, protein
    )
    
    results <- SPARQL(endpoint_sparql, query_alt_label)$results
  }
  
  # Check if results are empty
  if (nrow(results) == 0) {
    return("No data available for the introduced protein or you may have introduced an instance that is not a protein.")
  } else {
    return(results)
  }
}

prot2ortho("BRCA1_HUMAN")
prot2ortho("P38398")
prot2ortho("BRCA1")
prot2ortho("BRCA11")
