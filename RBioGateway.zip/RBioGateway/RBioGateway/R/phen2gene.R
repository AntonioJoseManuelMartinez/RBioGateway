# Function to get genes related to a given phenotype
## input: phenotype (e.g., a disease name or OMIM ID)
## output: list of genes associated with the phenotype

phen2gene <- function(phenotype) {
  library(SPARQL)
  
  # Endpoint SPARQL
  endpoint_sparql <- "https://2407.biogateway.eu/sparql"
  
  # Query building for general phenotype search
  query <- sprintf(
    "
    PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
    PREFIX sio: <http://semanticscience.org/resource/>
    PREFIX obo: <http://purl.obolibrary.org/obo/>
    SELECT DISTINCT ?gene_name
    WHERE {
        GRAPH <http://rdf.biogateway.eu/graph/omim> {
            {?omim_id skos:prefLabel ?label}
            UNION
            {?omim_id skos:altLabel ?label}
        }
        FILTER regex(?label, \"%s\", \"i\")
        GRAPH <http://rdf.biogateway.eu/graph/gene2phen> {
            ?gene obo:RO_0002331 ?omim_id .
        }
        GRAPH <http://rdf.biogateway.eu/graph/gene> {
            ?gene sio:SIO_010078 ?prot ;
                  skos:prefLabel ?gene_name.
        }
    }
    ",
    phenotype
  )
  
  # Run query
  results <- SPARQL(endpoint_sparql, query)$results
  
  # Check if results are empty
  if (nrow(results) == 0) {
    # Check if the phenotype is a valid OMIM identifier
    if (grepl("^MTHU|^[0-9]{6}$", phenotype)) {
      query_phen <- sprintf(
        "
        PREFIX omim: <http://purl.bioontology.org/ontology/OMIM/>
        PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
        PREFIX obo: <http://purl.obolibrary.org/obo/>
        SELECT DISTINCT ?gene_name
        WHERE {
            GRAPH  <http://rdf.biogateway.eu/graph/gene2phen> {
                ?gene obo:RO_0002331 omim:%s .
            }
            GRAPH <http://rdf.biogateway.eu/graph/gene> {
                ?gene skos:prefLabel ?gene_name.  
            }
        }
        ",
        phenotype
      )
      results <- SPARQL(endpoint_sparql, query_phen)$results
    }
  }
  
  # Check if we have results
  if (nrow(results) != 0) {
    # Sort results by gene name
    results_sorted <- results[order(results$gene_name), ]
    return(results_sorted)
  } else {
    return("No data available for the introduced phenotype or you may have introduced an instance that is not a phenotype. Check your data type with type_data function.")
  }
}

#Example
phen2gene("lung cancer")