# Function to retrieve proteins associated with a given gene, optionally filtered by taxon.
# Input:
##   gene: gene name. Example: "BRCA1"
##   taxon: taxon identifier (numeric or name), or NULL if not specified.
# Output: table with protein names associated with the gene.

gene2prot <- function(gene, taxon = NULL) {
  library(SPARQL)
  
  # Define the SPARQL endpoint
  endpoint_sparql <- "https://2407.biogateway.eu/sparql"
  
  # Case when taxon is NULL
  if (is.null(taxon)) {
    query <- sprintf(
      "
      PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
      PREFIX sio: <http://semanticscience.org/resource/>
      SELECT DISTINCT ?prot ?prot_name  
      WHERE {
          GRAPH <http://rdf.biogateway.eu/graph/gene> {
              ?gene skos:prefLabel '%s';
                    sio:SIO_010078 ?prot .
          }
          GRAPH <http://rdf.biogateway.eu/graph/prot> {
              ?prot skos:prefLabel ?prot_name .
          }
      }
      ",
      gene
    )
    # Execute the query
    results <- SPARQL(endpoint_sparql, query)$results$prot_name
    # Check if there are results
    if (length(results) == 0) {
      return("No data available for the introduced gene. Check that the gene id is correct or if you have introduced the taxon correctly.")
    } else {
      # Sort the results by protein name
      results = sort(results)
      return(results)
    }
  } else {
    # Case when taxon is provided as a numeric value
    if (!is.na(suppressWarnings(as.numeric(taxon)))) {
      query <- sprintf(
        "
        PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
        PREFIX gene: <http://rdf.biogateway.eu/gene/%s/>
        PREFIX sio: <http://semanticscience.org/resource/>
        SELECT DISTINCT ?prot ?prot_name  
        WHERE {
            GRAPH <http://rdf.biogateway.eu/graph/gene> {
                gene:%s sio:SIO_010078 ?prot .
            }
            GRAPH <http://rdf.biogateway.eu/graph/prot> {
                ?prot skos:prefLabel ?prot_name .
            }
        }
        ",
        taxon, gene
      )
      # Execute the query
      results <- SPARQL(endpoint_sparql, query)$results$prot_name
      # Check if there are results
      if (length(results) == 0) {
        return("No data available for the introduced gene. Check that the gene id is correct or if you have introduced the taxon correctly.")
      } else {
        return(sort(results))
      }
    } else {
      # Case when taxon is provided as a name
      query <- sprintf(
        "
        PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
        PREFIX sio: <http://semanticscience.org/resource/>
        PREFIX obo: <http://purl.obolibrary.org/obo/>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        SELECT DISTINCT ?prot ?prot_name  
        WHERE {
            GRAPH <http://rdf.biogateway.eu/graph/gene> {
              ?gene skos:prefLabel '%s';
                    sio:SIO_010078 ?prot ;
                    obo:RO_0002162 ?taxon .
            }
            GRAPH <http://rdf.biogateway.eu/graph/taxon> {
              ?taxon rdfs:label '%s' .
            }
            GRAPH <http://rdf.biogateway.eu/graph/prot> {
                ?prot skos:prefLabel ?prot_name .
            }
        }
        ",
        gene, taxon
      )
      # Execute the query
      results <- SPARQL(endpoint_sparql, query)$results$prot_name
      # Check if there are results
      if (length(results) == 0) {
        return("No data available for the introduced gene. Check that the gene id is correct or if you have introduced the taxon correctly.")
      } else {
        return(sort(results))
      }
    }
  }
}

# Examples:
gene2prot("TOX3")
gene2prot("TOX33")
gene2prot("TOX3","9606")
gene2prot("TOX3",9606)
gene2prot("Tox3","10090")
gene2prot("Tox3","Mus musculus")
