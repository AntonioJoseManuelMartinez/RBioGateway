# Function to obtain the main features of a protein
## input: 
### protein: name of the protein (protein). Example: "TBX5_HUMAN"
### sources: if you wish to include the sources (TRUE of FALSE). By default sources = T
## output: main data of a protein (id, definition, evidence level, articles and alternative sources)

getProtein_info <- function(protein, sources = T) {
  library(SPARQL)

  # Endpoint SPARQL
  sparql_endpoint <- "https://2407.biogateway.eu/sparql"

  # Query building
  if (sources == T) {
  query <- sprintf(
    "
    PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
    PREFIX obo: <http://purl.obolibrary.org/obo/>
    PREFIX schema: <http://schema.org/>
    PREFIX sio: <http://semanticscience.org/resource/>
    SELECT DISTINCT ?protein_alt_id ?definition ?evidence_level ?articles ?alt_sources
    WHERE {
        GRAPH <http://rdf.biogateway.eu/graph/prot> {
            ?prot skos:prefLabel \"%s\" ;
                  skos:altLabel ?protein_alt_id ;
                  skos:definition ?definition ;
                  schema:evidenceLevel ?evidence_level .
            OPTIONAL { ?prot sio:SIO_000772 ?articles. }
            OPTIONAL { ?prot skos:closeMatch ?alt_sources. }
        }
    }
    ",
    protein
  )
  } else {
    query <- sprintf(
    "
    PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
    PREFIX obo: <http://purl.obolibrary.org/obo/>
    PREFIX schema: <http://schema.org/>
    PREFIX sio: <http://semanticscience.org/resource/>
    SELECT DISTINCT ?protein_alt_id ?definition ?evidence_level
    WHERE {
        GRAPH <http://rdf.biogateway.eu/graph/prot> {
            ?prot skos:prefLabel \"%s\" ;
                  skos:altLabel ?protein_alt_id ;
                  skos:definition ?definition ;
                  schema:evidenceLevel ?evidence_level .
        }
    }
    ",
    protein
  )
  }
  
  # Run query
  results <- SPARQL(sparql_endpoint, query)$results
  
  # Check results
  if (is.null(results) || nrow(results) == 0) {
    return("No data available for the introduced protein or you may have introduced an instance that is not a protein. Check your data type with type_data function.")
  } else {
    combined_result <- list(
      protein_alt_ids = unique(results$protein_alt_id),
      definition = unique(results$definition),
      evidence_level = unique(results$evidence_level),
      articles = unique(results$articles),
      alt_sources = unique(results$alt_sources)
    )
    combined_result$articles = gsub("http://identifiers.org/pubmed/", "PMID:", combined_result$articles)
    combined_result$articles = gsub("<|>", "", combined_result$articles)
    
    combined_result$alt_sources = gsub("http://identifiers.org/.*/", "", combined_result$alt_sources)
    combined_result$alt_sources = gsub("<|>", "", combined_result$alt_sources)
    
    return(combined_result)
  }
}

#Examples:
getProtein_info("TBX5_HUMAN")
